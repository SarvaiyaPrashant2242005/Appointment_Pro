# AppointmentPro — MySQL Database Schema & Backend Architecture Specification

> **Project:** AppointmentPro (Booking & Business Manager)  
> **Target Database:** MySQL 8.0+  
> **Engine:** InnoDB  
> **Default Character Set:** `utf8mb4`  
> **Default Collation:** `utf8mb4_unicode_ci`  
> **Architecture Pattern:** Multi-Tenant Business Management with Public Client Self-Booking

---

## 1. System Overview & Architecture Analysis

### Current State (Flutter Frontend)
The frontend Flutter application currently relies on a client-side prototype persistence layer backed by `shared_preferences` (`LocalStorageService`, `booking_local_datasource.dart`, `business_repository.dart`, etc.). Data is stored as JSON strings for:
- User profile & authentication credentials
- Business profiles (with active business selection)
- Services & pricing catalog
- Staff profiles, service assignments, and individual schedules
- Weekly operating hours, break intervals, and time-off/holiday records
- Bookings, status transitions (`confirmed`, `completed`, `cancelled`, `noShow`), and reschedule audit history
- Notifications & Firebase Cloud Messaging (FCM) topics
- Aggregate reporting and customer records derived on-the-fly

### Target Architecture (Backend with MySQL)
The application will transition to a secure client-server model:
1. **Multi-Tenancy:** A user (business owner or staff member) can manage one or multiple businesses. Each business owns its services, staff, operating hours, customers, bookings, and financial analytics.
2. **Public Booking Portal:** External clients book appointments through URL slugs (e.g., `/book/:businessSlug`) without requiring an account. Bookings generate a human-readable booking reference (`booking_reference`) for self-service verification and rescheduling.
3. **Relational Integrity:** Foreign keys enforce strict referential integrity, prevent orphan records, and maintain historical accuracy through status audits and snapshot columns.
4. **Double-Booking Prevention:** High-performance composite indexing on `(business_id, staff_id, start_at, end_at)` and transaction-isolated slot calculation guarantees concurrency safety.

---

## 2. Entity-Relationship Diagram (ERD)

```mermaid
erDiagram
    USERS ||--o{ BUSINESSES : "owns"
    USERS ||--o{ BUSINESS_MEMBERS : "participates in"
    BUSINESSES ||--o{ BUSINESS_MEMBERS : "has"
    BUSINESSES ||--o{ SERVICES : "offers"
    BUSINESSES ||--o{ STAFF : "employs"
    BUSINESSES ||--o{ CUSTOMERS : "serves"
    BUSINESSES ||--o{ BUSINESS_OPERATING_HOURS : "configures"
    BUSINESSES ||--o{ TIME_OFF_RECORDS : "declares"
    BUSINESSES ||--o{ BOOKINGS : "receives"
    BUSINESSES ||--o{ NOTIFICATIONS : "triggers"
    BUSINESSES ||--o{ FCM_DEVICE_TOKENS : "registers"

    STAFF ||--o{ STAFF_SERVICES : "is assigned to"
    SERVICES ||--o{ STAFF_SERVICES : "assigned staff"

    BUSINESS_OPERATING_HOURS ||--o{ BUSINESS_SCHEDULE_BREAKS : "includes"
    STAFF ||--o{ STAFF_OPERATING_HOURS : "custom schedule"
    STAFF_OPERATING_HOURS ||--o{ STAFF_SCHEDULE_BREAKS : "includes"

    STAFF ||--o{ TIME_OFF_RECORDS : "takes leave"
    STAFF ||--o{ BOOKINGS : "fulfills"

    SERVICES ||--o{ BOOKINGS : "booked for"
    CUSTOMERS ||--o{ BOOKINGS : "places"

    BOOKINGS ||--o{ BOOKING_RESCHEDULES : "has history"
    BOOKINGS ||--o{ PAYMENTS : "billed via"
    BOOKINGS ||--o{ REVIEWS : "evaluated by"
    BOOKINGS ||--o{ NOTIFICATIONS : "causes"

    USERS {
        VARCHAR_36 id PK
        VARCHAR_100 full_name
        VARCHAR_191 email UK
        VARCHAR_20 phone
        VARCHAR_255 password_hash
        ENUM role
        BOOLEAN is_active
        DATETIME created_at
        DATETIME updated_at
    }

    BUSINESSES {
        VARCHAR_36 id PK
        VARCHAR_36 owner_id FK
        VARCHAR_255 name
        VARCHAR_255 slug UK
        VARCHAR_100 type
        VARCHAR_100 other_type
        VARCHAR_500 logo_url
        VARCHAR_191 email
        VARCHAR_10 country_code
        VARCHAR_20 phone
        VARCHAR_10 currency
        VARCHAR_100 timezone
        BOOLEAN is_active
        DATETIME created_at
        DATETIME updated_at
    }

    SERVICES {
        VARCHAR_36 id PK
        VARCHAR_36 business_id FK
        VARCHAR_255 name
        TEXT description
        DECIMAL price
        INT duration_minutes
        INT buffer_minutes
        BOOLEAN is_active
        DATETIME created_at
        DATETIME updated_at
    }

    STAFF {
        VARCHAR_36 id PK
        VARCHAR_36 business_id FK
        VARCHAR_36 user_id FK
        VARCHAR_255 name
        VARCHAR_191 email
        VARCHAR_20 phone
        VARCHAR_500 avatar_url
        BOOLEAN is_active
        DATETIME created_at
        DATETIME updated_at
    }

    STAFF_SERVICES {
        VARCHAR_36 staff_id PK,FK
        VARCHAR_36 service_id PK,FK
        DATETIME created_at
    }

    CUSTOMERS {
        VARCHAR_36 id PK
        VARCHAR_36 business_id FK
        VARCHAR_255 name
        VARCHAR_10 country_code
        VARCHAR_20 phone
        VARCHAR_191 email
        TEXT notes
        DATETIME created_at
        DATETIME updated_at
    }

    BOOKINGS {
        VARCHAR_36 id PK
        VARCHAR_20 booking_reference UK
        VARCHAR_36 business_id FK
        VARCHAR_36 service_id FK
        VARCHAR_36 staff_id FK
        VARCHAR_36 customer_id FK
        VARCHAR_255 service_name
        VARCHAR_255 staff_name
        VARCHAR_255 customer_name
        VARCHAR_10 customer_country_code
        VARCHAR_20 customer_phone
        VARCHAR_191 customer_email
        TEXT customer_notes
        DATETIME start_at
        DATETIME end_at
        DECIMAL price
        ENUM status
        TEXT cancellation_reason
        DATETIME cancelled_at
        DATETIME created_at
        DATETIME updated_at
    }

    BOOKING_RESCHEDULES {
        VARCHAR_36 id PK
        VARCHAR_36 booking_id FK
        DATETIME previous_start_at
        DATETIME previous_end_at
        DATETIME new_start_at
        DATETIME new_end_at
        VARCHAR_36 previous_staff_id FK
        VARCHAR_36 new_staff_id FK
        TEXT reason
        DATETIME rescheduled_at
    }

    BUSINESS_OPERATING_HOURS {
        VARCHAR_36 id PK
        VARCHAR_36 business_id FK
        TINYINT day_of_week
        BOOLEAN is_open
        TIME open_time
        TIME close_time
    }

    BUSINESS_SCHEDULE_BREAKS {
        VARCHAR_36 id PK
        VARCHAR_36 operating_hour_id FK
        VARCHAR_100 break_name
        TIME start_time
        TIME end_time
    }

    TIME_OFF_RECORDS {
        VARCHAR_36 id PK
        VARCHAR_36 business_id FK
        VARCHAR_36 staff_id FK
        VARCHAR_255 title
        DATETIME start_date
        DATETIME end_date
        BOOLEAN is_full_day
        TEXT note
        DATETIME created_at
    }

    NOTIFICATIONS {
        VARCHAR_36 id PK
        VARCHAR_36 business_id FK
        VARCHAR_36 user_id FK
        VARCHAR_36 booking_id FK
        ENUM type
        VARCHAR_255 title
        TEXT body
        VARCHAR_255 customer_name
        VARCHAR_255 service_name
        DATETIME start_at
        DATETIME end_at
        TEXT cancellation_reason
        BOOLEAN is_read
        JSON metadata
        DATETIME created_at
    }
```

---

## 3. Detailed Table Specifications & Columns

### 3.1. `users`
Stores system users (business owners, managers, and staff members).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `full_name` | `VARCHAR(100)` | `NOT NULL` | User full name |
| `email` | `VARCHAR(191)` | `NOT NULL, UNIQUE` | Normalized lowercase email address |
| `phone` | `VARCHAR(20)` | `NOT NULL` | Contact mobile number |
| `password_hash` | `VARCHAR(255)` | `NOT NULL` | Bcrypt / Argon2 hashed password |
| `role` | `ENUM('owner','manager','staff','customer')` | `NOT NULL DEFAULT 'owner'` | System authorization role |
| `avatar_url` | `VARCHAR(500)` | `NULL` | Profile avatar image link |
| `is_active` | `TINYINT(1)` | `NOT NULL DEFAULT 1` | 1 = Active, 0 = Deactivated |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Creation timestamp |
| `updated_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Modification timestamp |

**Indexes:**
- `UNIQUE INDEX idx_users_email (email)`
- `INDEX idx_users_phone (phone)`

---

### 3.2. `businesses`
Multi-tenant business profiles configured in `business_setup` and `business_list`.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `owner_id` | `VARCHAR(36)` | `NOT NULL, FK -> users(id)` | User who registered the business |
| `name` | `VARCHAR(255)` | `NOT NULL` | Business name (e.g. "Apex Wellness Center") |
| `slug` | `VARCHAR(255)` | `NOT NULL, UNIQUE` | Clean URL slug for public booking (`/book/:slug`) |
| `type` | `VARCHAR(100)` | `NOT NULL` | Category ('Salon / Beauty', 'Healthcare / Hospital', etc.) |
| `other_type` | `VARCHAR(100)` | `NULL` | Custom type when `type = 'Other'` |
| `logo_url` | `VARCHAR(500)` | `NULL` | URL/Path to business logo |
| `email` | `VARCHAR(191)` | `NULL` | Public contact email |
| `country_code` | `VARCHAR(10)` | `NOT NULL DEFAULT '+91'` | Country phone dial code |
| `phone` | `VARCHAR(20)` | `NULL` | Public contact phone number |
| `currency` | `VARCHAR(10)` | `NOT NULL DEFAULT 'INR'` | Currency code (INR, USD, etc.) |
| `timezone` | `VARCHAR(100)` | `NOT NULL DEFAULT 'Asia/Kolkata'` | IANA timezone for calendar scheduling |
| `is_active` | `TINYINT(1)` | `NOT NULL DEFAULT 0` | Current active business for logged-in session |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Record creation date |
| `updated_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Last updated date |

**Indexes & Constraints:**
- `UNIQUE INDEX idx_businesses_slug (slug)`
- `INDEX idx_businesses_owner (owner_id)`
- `FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE RESTRICT`

---

### 3.3. `business_members`
Association table connecting users to businesses with role-based access control.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Business identifier |
| `user_id` | `VARCHAR(36)` | `NOT NULL, FK -> users(id)` | User identifier |
| `role` | `ENUM('owner','manager','staff')` | `NOT NULL DEFAULT 'staff'` | Member role within business |
| `is_active` | `TINYINT(1)` | `NOT NULL DEFAULT 1` | Membership active status |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Association timestamp |

**Indexes & Constraints:**
- `UNIQUE INDEX idx_business_user (business_id, user_id)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`
- `FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE`

---

### 3.4. `services`
Catalog of bookable services managed per business.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Owning business |
| `name` | `VARCHAR(255)` | `NOT NULL` | Service name (e.g. "Haircut & Styling") |
| `description` | `TEXT` | `NULL` | Detailed service description |
| `price` | `DECIMAL(10,2)` | `NOT NULL DEFAULT 0.00` | Service fee |
| `duration_minutes` | `INT` | `NOT NULL DEFAULT 30` | Duration in minutes (15, 30, 45, 60, etc.) |
| `buffer_minutes` | `INT` | `NOT NULL DEFAULT 0` | Buffer/cleanup time required post-service |
| `is_active` | `TINYINT(1)` | `NOT NULL DEFAULT 1` | Visible in booking form |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Creation timestamp |
| `updated_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Modification timestamp |

**Indexes & Constraints:**
- `INDEX idx_services_business_active (business_id, is_active)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`

---

### 3.5. `staff`
Team members delivering services within a business.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Owning business |
| `user_id` | `VARCHAR(36)` | `NULL, FK -> users(id)` | Optional link to user login account |
| `name` | `VARCHAR(255)` | `NOT NULL` | Staff member full name |
| `email` | `VARCHAR(191)` | `NULL` | Staff notification email |
| `phone` | `VARCHAR(20)` | `NULL` | Staff contact phone |
| `avatar_url` | `VARCHAR(500)` | `NULL` | Staff photo/avatar |
| `is_active` | `TINYINT(1)` | `NOT NULL DEFAULT 1` | 1 = Active & bookable, 0 = Inactive |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Creation timestamp |
| `updated_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Modification timestamp |

**Indexes & Constraints:**
- `INDEX idx_staff_business_active (business_id, is_active)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`
- `FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL`

---

### 3.6. `staff_services`
Many-to-Many junction table mapping staff members to the services they are qualified to perform.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `staff_id` | `VARCHAR(36)` | `NOT NULL, FK -> staff(id)` | Assigned staff member |
| `service_id` | `VARCHAR(36)` | `NOT NULL, FK -> services(id)` | Eligible service |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Assignment timestamp |

**Indexes & Constraints:**
- `PRIMARY KEY (staff_id, service_id)`
- `INDEX idx_staff_services_service (service_id)`
- `FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE`
- `FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE`

---

### 3.7. `business_operating_hours`
Weekly operating hours schedule for each business (corresponds to `BusinessAvailability` in Flutter).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Owning business |
| `day_of_week` | `TINYINT` | `NOT NULL` | 1 = Monday, 2 = Tuesday, ..., 7 = Sunday |
| `is_open` | `TINYINT(1)` | `NOT NULL DEFAULT 1` | Whether the business is open on this day |
| `open_time` | `TIME` | `NOT NULL DEFAULT '09:00:00'` | Opening time ("HH:mm") |
| `close_time` | `TIME` | `NOT NULL DEFAULT '18:00:00'` | Closing time ("HH:mm") |

**Indexes & Constraints:**
- `UNIQUE INDEX idx_business_day (business_id, day_of_week)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`

---

### 3.8. `business_schedule_breaks`
Intermittent break intervals during operating hours (e.g. Lunch 13:00 - 14:00).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `operating_hour_id` | `VARCHAR(36)` | `NOT NULL, FK -> business_operating_hours(id)` | Target operating schedule day |
| `break_name` | `VARCHAR(100)` | `NOT NULL DEFAULT 'Break'` | Label (e.g. "Lunch Break") |
| `start_time` | `TIME` | `NOT NULL` | Break start time ("HH:mm") |
| `end_time` | `TIME` | `NOT NULL` | Break end time ("HH:mm") |

**Indexes & Constraints:**
- `INDEX idx_breaks_operating_hour (operating_hour_id)`
- `FOREIGN KEY (operating_hour_id) REFERENCES business_operating_hours(id) ON DELETE CASCADE`

---

### 3.9. `staff_operating_hours` & `staff_schedule_breaks` (Optional Staff Schedule Overrides)
Overrides default business hours for specific staff working shifts.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `staff_id` | `VARCHAR(36)` | `NOT NULL, FK -> staff(id)` | Staff member |
| `day_of_week` | `TINYINT` | `NOT NULL` | 1 = Mon to 7 = Sun |
| `is_working` | `TINYINT(1)` | `NOT NULL DEFAULT 1` | Available on this day |
| `start_time` | `TIME` | `NOT NULL DEFAULT '09:00:00'` | Shift start |
| `end_time` | `TIME` | `NOT NULL DEFAULT '18:00:00'` | Shift end |

**Indexes & Constraints:**
- `UNIQUE INDEX idx_staff_day (staff_id, day_of_week)`
- `FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE`

---

### 3.10. `time_off_records`
Business-wide holidays and individual staff leaves (matches `TimeOffRecord` in Flutter).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Target business |
| `staff_id` | `VARCHAR(36)` | `NULL, FK -> staff(id)` | `NULL` = Business holiday; non-null = Staff leave |
| `title` | `VARCHAR(255)` | `NOT NULL` | Event/Reason (e.g. "National Holiday", "Medical Leave") |
| `start_date` | `DATETIME` | `NOT NULL` | Leave start datetime |
| `end_date` | `DATETIME` | `NOT NULL` | Leave end datetime |
| `is_full_day` | `TINYINT(1)` | `NOT NULL DEFAULT 1` | 1 = Entire day, 0 = Partial hours |
| `note` | `TEXT` | `NULL` | Internal remarks |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Entry creation timestamp |

**Indexes & Constraints:**
- `INDEX idx_time_off_range (business_id, staff_id, start_date, end_date)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`
- `FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE CASCADE`

---

### 3.11. `customers`
Customer relationship records (CRM) aggregated per business.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Owning business scope |
| `name` | `VARCHAR(255)` | `NOT NULL` | Customer name |
| `country_code` | `VARCHAR(10)` | `NOT NULL DEFAULT '+91'` | Country dial code |
| `phone` | `VARCHAR(20)` | `NOT NULL` | Customer mobile number |
| `email` | `VARCHAR(191)` | `NULL` | Customer email |
| `notes` | `TEXT` | `NULL` | Customer preferences / allergies / history |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Initial booking / registration date |
| `updated_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Last updated date |

**Indexes & Constraints:**
- `UNIQUE INDEX idx_customer_business_phone (business_id, phone)`
- `INDEX idx_customer_business_email (business_id, email)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`

---

### 3.12. `bookings`
Core appointment records (matches `BookingModel` in Flutter).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `booking_reference` | `VARCHAR(20)` | `NOT NULL, UNIQUE` | Short readable tracking code (e.g. `BK-84729`) |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Owning business |
| `service_id` | `VARCHAR(36)` | `NOT NULL, FK -> services(id)` | Booked service |
| `staff_id` | `VARCHAR(36)` | `NULL, FK -> staff(id)` | Assigned staff (`NULL` = Unassigned / Any) |
| `customer_id` | `VARCHAR(36)` | `NOT NULL, FK -> customers(id)` | Customer entity reference |
| `service_name` | `VARCHAR(255)` | `NOT NULL` | Historical snapshot of service name |
| `staff_name` | `VARCHAR(255)` | `NULL` | Historical snapshot of staff name |
| `customer_name` | `VARCHAR(255)` | `NOT NULL` | Snapshot of customer name at booking time |
| `customer_country_code` | `VARCHAR(10)` | `NOT NULL DEFAULT '+91'` | Country code |
| `customer_phone` | `VARCHAR(20)` | `NOT NULL` | Phone number |
| `customer_email` | `VARCHAR(191)` | `NULL` | Customer email |
| `customer_notes` | `TEXT` | `NULL` | Special client requests |
| `start_at` | `DATETIME` | `NOT NULL` | Appointment start date and time |
| `end_at` | `DATETIME` | `NOT NULL` | Appointment end date and time |
| `price` | `DECIMAL(10,2)` | `NOT NULL DEFAULT 0.00` | Agreed price at booking time |
| `status` | `ENUM('confirmed','completed','cancelled','noShow')` | `NOT NULL DEFAULT 'confirmed'` | Current booking state |
| `cancellation_reason` | `TEXT` | `NULL` | Reason provided if cancelled |
| `cancelled_at` | `DATETIME` | `NULL` | Cancellation timestamp |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Booking placement timestamp |
| `updated_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Last updated timestamp |

**Indexes & Performance Optimization:**
- `UNIQUE INDEX idx_booking_ref (booking_reference)`
- `INDEX idx_bookings_availability (business_id, staff_id, status, start_at, end_at)`
- `INDEX idx_bookings_date_range (business_id, start_at, status)`
- `INDEX idx_bookings_customer (business_id, customer_id)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`
- `FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE RESTRICT`
- `FOREIGN KEY (staff_id) REFERENCES staff(id) ON DELETE SET NULL`
- `FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT`

---

### 3.13. `booking_reschedules`
Audit log of all appointment reschedules (matches `RescheduleRecord` in Flutter).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `booking_id` | `VARCHAR(36)` | `NOT NULL, FK -> bookings(id)` | Target booking |
| `previous_start_at` | `DATETIME` | `NOT NULL` | Prior start datetime |
| `previous_end_at` | `DATETIME` | `NOT NULL` | Prior end datetime |
| `new_start_at` | `DATETIME` | `NOT NULL` | Rescheduled start datetime |
| `new_end_at` | `DATETIME` | `NOT NULL` | Rescheduled end datetime |
| `previous_staff_id` | `VARCHAR(36)` | `NULL, FK -> staff(id)` | Previous staff member |
| `new_staff_id` | `VARCHAR(36)` | `NULL, FK -> staff(id)` | New staff member |
| `reason` | `TEXT` | `NULL` | Explanation for rescheduling |
| `rescheduled_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Action timestamp |

**Indexes & Constraints:**
- `INDEX idx_reschedules_booking (booking_id)`
- `FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE`
- `FOREIGN KEY (previous_staff_id) REFERENCES staff(id) ON DELETE SET NULL`
- `FOREIGN KEY (new_staff_id) REFERENCES staff(id) ON DELETE SET NULL`

---

### 3.14. `notifications`
In-app and push notification log (replaces direct Firestore reliance with MySQL persistence).

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Business receiving notification |
| `user_id` | `VARCHAR(36)` | `NULL, FK -> users(id)` | Optional specific recipient user |
| `booking_id` | `VARCHAR(36)` | `NULL, FK -> bookings(id)` | Associated booking |
| `type` | `ENUM('new_booking','booking_cancelled','booking_rescheduled','reminder','system')` | `NOT NULL` | Category |
| `title` | `VARCHAR(255)` | `NOT NULL` | Display title |
| `body` | `TEXT` | `NOT NULL` | Notification message |
| `customer_name` | `VARCHAR(255)` | `NOT NULL` | Client name |
| `service_name` | `VARCHAR(255)` | `NOT NULL` | Service name |
| `start_at` | `DATETIME` | `NULL` | Appointment start |
| `end_at` | `DATETIME` | `NULL` | Appointment end |
| `cancellation_reason` | `TEXT` | `NULL` | Cancellation note if applicable |
| `is_read` | `TINYINT(1)` | `NOT NULL DEFAULT 0` | 1 = Read, 0 = Unread |
| `metadata` | `JSON` | `NULL` | Additional structured data |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Trigger timestamp |

**Indexes & Constraints:**
- `INDEX idx_notifs_business_unread (business_id, is_read, created_at)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`
- `FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE`
- `FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL`

---

### 3.15. `fcm_device_tokens`
FCM push notification tokens for mobile and web clients.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `user_id` | `VARCHAR(36)` | `NULL, FK -> users(id)` | User owning the device |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Business context |
| `token` | `VARCHAR(512)` | `NOT NULL, UNIQUE` | FCM registration token |
| `platform` | `ENUM('android','ios','web','macos','windows')` | `NOT NULL DEFAULT 'android'` | Client OS |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Registration date |
| `updated_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP` | Last token refresh |

**Indexes & Constraints:**
- `UNIQUE INDEX idx_fcm_token (token)`
- `INDEX idx_fcm_business (business_id)`
- `FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`

---

### 3.16. `payments` (Financial Tracking & Invoicing)
Tracks payments received for completed or online-booked appointments.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Owning business |
| `booking_id` | `VARCHAR(36)` | `NOT NULL, FK -> bookings(id)` | Associated booking |
| `customer_id` | `VARCHAR(36)` | `NOT NULL, FK -> customers(id)` | Paying customer |
| `amount` | `DECIMAL(10,2)` | `NOT NULL DEFAULT 0.00` | Payment amount |
| `method` | `ENUM('cash','upi','card','online','bank_transfer','other')` | `NOT NULL DEFAULT 'cash'` | Payment method |
| `status` | `ENUM('pending','completed','refunded','failed')` | `NOT NULL DEFAULT 'completed'` | Transaction status |
| `transaction_reference`| `VARCHAR(100)` | `NULL` | Gateway TXN ID or UPI ref number |
| `paid_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Payment timestamp |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Record creation date |

**Indexes & Constraints:**
- `INDEX idx_payments_booking (booking_id)`
- `INDEX idx_payments_business_date (business_id, paid_at)`
- `FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE`
- `FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE`
- `FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE RESTRICT`

---

### 3.17. `reviews` (Customer Feedback)
Ratings and customer reviews linked to appointments.

| Column | Type | Constraints | Description |
|---|---|---|---|
| `id` | `VARCHAR(36)` | `PRIMARY KEY` | UUID v4 |
| `business_id` | `VARCHAR(36)` | `NOT NULL, FK -> businesses(id)` | Target business |
| `booking_id` | `VARCHAR(36)` | `NOT NULL, UNIQUE, FK -> bookings(id)` | 1 review per booking |
| `customer_id` | `VARCHAR(36)` | `NOT NULL, FK -> customers(id)` | Reviewer |
| `staff_id` | `VARCHAR(36)` | `NULL, FK -> staff(id)` | Reviewed staff member |
| `service_id` | `VARCHAR(36)` | `NOT NULL, FK -> services(id)` | Reviewed service |
| `rating` | `TINYINT` | `NOT NULL CHECK (rating BETWEEN 1 AND 5)` | 1 to 5 star rating |
| `comment` | `TEXT` | `NULL` | Review text |
| `reply` | `TEXT` | `NULL` | Business owner reply |
| `created_at` | `DATETIME` | `NOT NULL DEFAULT CURRENT_TIMESTAMP` | Submission timestamp |

---

## 4. Referential Integrity & Relational Summary

| Parent Table | Child Table | Foreign Key Column | Cardinality | On Delete Action | Business Reason |
|---|---|---|---|---|---|
| `users` | `businesses` | `owner_id` | 1 : N | `RESTRICT` | Prevent deleting a user if they own active businesses. |
| `businesses` | `business_members` | `business_id` | 1 : N | `CASCADE` | Member records clean up if business is deleted. |
| `users` | `business_members` | `user_id` | 1 : N | `CASCADE` | Member associations remove if user is deleted. |
| `businesses` | `services` | `business_id` | 1 : N | `CASCADE` | Deleting business deletes its service catalog. |
| `businesses` | `staff` | `business_id` | 1 : N | `CASCADE` | Deleting business deletes staff entries. |
| `users` | `staff` | `user_id` | 1 : 1 (opt) | `SET NULL` | Deleting user account keeps historical staff member data. |
| `staff` | `staff_services` | `staff_id` | 1 : N | `CASCADE` | Junction rows remove when staff is deleted. |
| `services` | `staff_services` | `service_id` | 1 : N | `CASCADE` | Junction rows remove when service is deleted. |
| `businesses` | `business_operating_hours` | `business_id` | 1 : 7 | `CASCADE` | Weekly schedule removes when business is deleted. |
| `business_operating_hours`| `business_schedule_breaks` | `operating_hour_id` | 1 : N | `CASCADE` | Breaks remove when operating day is modified/deleted. |
| `businesses` | `time_off_records` | `business_id` | 1 : N | `CASCADE` | Holidays remove when business is deleted. |
| `staff` | `time_off_records` | `staff_id` | 1 : N | `CASCADE` | Staff leaves remove when staff member is deleted. |
| `businesses` | `customers` | `business_id` | 1 : N | `CASCADE` | Deleting business deletes its private customer CRM. |
| `businesses` | `bookings` | `business_id` | 1 : N | `CASCADE` | Deleting business deletes bookings. |
| `services` | `bookings` | `service_id` | 1 : N | `RESTRICT` | Cannot delete service with existing booking history (deactivate instead). |
| `staff` | `bookings` | `staff_id` | 1 : N | `SET NULL` | Deleting staff unassigns staff from historical bookings without deleting bookings. |
| `customers` | `bookings` | `customer_id` | 1 : N | `RESTRICT` | Cannot delete customer with active booking ledger. |
| `bookings` | `booking_reschedules`| `booking_id` | 1 : N | `CASCADE` | Audit entries remove when parent booking is deleted. |
| `bookings` | `notifications` | `booking_id` | 1 : N | `SET NULL` | Notification remains readable even if booking is purged. |
| `bookings` | `payments` | `booking_id` | 1 : N | `CASCADE` | Financial record clean up on booking purge. |

---

## 5. Booking Availability Calculation Logic (Database Implementation)

In `AppointmentPro`, availability calculation (`booking_availability_calculator.dart`) requires checking 4 constraints:
1. **Operating Day & Hours:** `business_operating_hours.is_open = 1` for `DAYOFWEEK(target_date)`.
2. **Business Holiday Check:** No record in `time_off_records` where `staff_id IS NULL` and `target_date BETWEEN start_date AND end_date`.
3. **Staff Holiday Check:** Staff member has no entry in `time_off_records` covering the slot.
4. **Existing Bookings Conflict Check:** Staff has no booking where `status = 'confirmed'` and `(start_at < slot_end AND end_at > slot_start)`.

### Optimized Query for Conflicting Bookings
```sql
SELECT 
    b.id,
    b.staff_id,
    b.start_at,
    b.end_at
FROM bookings b
WHERE b.business_id = ?
  AND b.status = 'confirmed'
  AND (b.staff_id = ? OR ? IS NULL)
  AND b.start_at < ?   -- Slot end time + buffer
  AND b.end_at > ?     -- Slot start time
FOR SHARE;
```

---

## 6. Complete Production MySQL DDL Script (`schema.sql`)

```sql
-- ========================================================
-- AppointmentPro: Full Production MySQL Schema
-- ========================================================

SET FOREIGN_KEY_CHECKS = 0;

-- 1. Users Table
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id VARCHAR(36) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(191) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('owner', 'manager', 'staff', 'customer') NOT NULL DEFAULT 'owner',
    avatar_url VARCHAR(500) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    INDEX idx_users_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Businesses Table
DROP TABLE IF EXISTS businesses;
CREATE TABLE businesses (
    id VARCHAR(36) NOT NULL,
    owner_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    other_type VARCHAR(100) NULL,
    logo_url VARCHAR(500) NULL,
    email VARCHAR(191) NULL,
    country_code VARCHAR(10) NOT NULL DEFAULT '+91',
    phone VARCHAR(20) NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'INR',
    timezone VARCHAR(100) NOT NULL DEFAULT 'Asia/Kolkata',
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_businesses_slug (slug),
    INDEX idx_businesses_owner (owner_id),
    CONSTRAINT fk_businesses_owner FOREIGN KEY (owner_id) 
        REFERENCES users (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. Business Members (Roles & Multi-User Business Access)
DROP TABLE IF EXISTS business_members;
CREATE TABLE business_members (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    role ENUM('owner', 'manager', 'staff') NOT NULL DEFAULT 'staff',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_business_user (business_id, user_id),
    CONSTRAINT fk_bm_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bm_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Services Table
DROP TABLE IF EXISTS services;
CREATE TABLE services (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    duration_minutes INT NOT NULL DEFAULT 30,
    buffer_minutes INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_services_business_active (business_id, is_active),
    CONSTRAINT fk_services_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Staff Table
DROP TABLE IF EXISTS staff;
CREATE TABLE staff (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(191) NULL,
    phone VARCHAR(20) NULL,
    avatar_url VARCHAR(500) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_staff_business_active (business_id, is_active),
    INDEX idx_staff_user (user_id),
    CONSTRAINT fk_staff_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_staff_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Staff Services Junction Table (M:N)
DROP TABLE IF EXISTS staff_services;
CREATE TABLE staff_services (
    staff_id VARCHAR(36) NOT NULL,
    service_id VARCHAR(36) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (staff_id, service_id),
    INDEX idx_staff_services_service (service_id),
    CONSTRAINT fk_ss_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ss_service FOREIGN KEY (service_id) 
        REFERENCES services (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. Business Operating Hours Table (1 = Monday, 7 = Sunday)
DROP TABLE IF EXISTS business_operating_hours;
CREATE TABLE business_operating_hours (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    day_of_week TINYINT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    is_open TINYINT(1) NOT NULL DEFAULT 1,
    open_time TIME NOT NULL DEFAULT '09:00:00',
    close_time TIME NOT NULL DEFAULT '18:00:00',
    PRIMARY KEY (id),
    UNIQUE KEY uq_business_day (business_id, day_of_week),
    CONSTRAINT fk_boh_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. Business Schedule Breaks Table
DROP TABLE IF EXISTS business_schedule_breaks;
CREATE TABLE business_schedule_breaks (
    id VARCHAR(36) NOT NULL,
    operating_hour_id VARCHAR(36) NOT NULL,
    break_name VARCHAR(100) NOT NULL DEFAULT 'Break',
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    PRIMARY KEY (id),
    INDEX idx_breaks_operating_hour (operating_hour_id),
    CONSTRAINT fk_bsb_operating_hour FOREIGN KEY (operating_hour_id) 
        REFERENCES business_operating_hours (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. Staff Operating Hours Table (Optional Custom Shifts)
DROP TABLE IF EXISTS staff_operating_hours;
CREATE TABLE staff_operating_hours (
    id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NOT NULL,
    day_of_week TINYINT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    is_working TINYINT(1) NOT NULL DEFAULT 1,
    start_time TIME NOT NULL DEFAULT '09:00:00',
    close_time TIME NOT NULL DEFAULT '18:00:00',
    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_day (staff_id, day_of_week),
    CONSTRAINT fk_soh_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. Staff Schedule Breaks Table
DROP TABLE IF EXISTS staff_schedule_breaks;
CREATE TABLE staff_schedule_breaks (
    id VARCHAR(36) NOT NULL,
    staff_operating_hour_id VARCHAR(36) NOT NULL,
    break_name VARCHAR(100) NOT NULL DEFAULT 'Break',
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    PRIMARY KEY (id),
    INDEX idx_staff_breaks_hour (staff_operating_hour_id),
    CONSTRAINT fk_ssb_staff_hour FOREIGN KEY (staff_operating_hour_id) 
        REFERENCES staff_operating_hours (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. Time Off Records (Holidays & Staff Leaves)
DROP TABLE IF EXISTS time_off_records;
CREATE TABLE time_off_records (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NULL,
    title VARCHAR(255) NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    is_full_day TINYINT(1) NOT NULL DEFAULT 1,
    note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_time_off_query (business_id, staff_id, start_date, end_date),
    CONSTRAINT fk_to_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_to_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. Customers Table (CRM Ledger)
DROP TABLE IF EXISTS customers;
CREATE TABLE customers (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    country_code VARCHAR(10) NOT NULL DEFAULT '+91',
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(191) NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_customer_business_phone (business_id, phone),
    INDEX idx_customer_business_email (business_id, email),
    CONSTRAINT fk_customers_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. Bookings Table
DROP TABLE IF EXISTS bookings;
CREATE TABLE bookings (
    id VARCHAR(36) NOT NULL,
    booking_reference VARCHAR(20) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    service_id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NULL,
    customer_id VARCHAR(36) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    staff_name VARCHAR(255) NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_country_code VARCHAR(10) NOT NULL DEFAULT '+91',
    customer_phone VARCHAR(20) NOT NULL,
    customer_email VARCHAR(191) NULL,
    customer_notes TEXT NULL,
    start_at DATETIME NOT NULL,
    end_at DATETIME NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('confirmed', 'completed', 'cancelled', 'noShow') NOT NULL DEFAULT 'confirmed',
    cancellation_reason TEXT NULL,
    cancelled_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_booking_ref (booking_reference),
    INDEX idx_bookings_availability (business_id, staff_id, status, start_at, end_at),
    INDEX idx_bookings_date_range (business_id, start_at, status),
    INDEX idx_bookings_customer (business_id, customer_id),
    CONSTRAINT fk_bookings_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bookings_service FOREIGN KEY (service_id) 
        REFERENCES services (id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_bookings_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_bookings_customer FOREIGN KEY (customer_id) 
        REFERENCES customers (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. Booking Reschedules Table (History & Audit Log)
DROP TABLE IF EXISTS booking_reschedules;
CREATE TABLE booking_reschedules (
    id VARCHAR(36) NOT NULL,
    booking_id VARCHAR(36) NOT NULL,
    previous_start_at DATETIME NOT NULL,
    previous_end_at DATETIME NOT NULL,
    new_start_at DATETIME NOT NULL,
    new_end_at DATETIME NOT NULL,
    previous_staff_id VARCHAR(36) NULL,
    new_staff_id VARCHAR(36) NULL,
    reason TEXT NULL,
    rescheduled_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_reschedules_booking (booking_id),
    CONSTRAINT fk_br_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_br_prev_staff FOREIGN KEY (previous_staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_br_new_staff FOREIGN KEY (new_staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. Notifications Table
DROP TABLE IF EXISTS notifications;
CREATE TABLE notifications (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NULL,
    booking_id VARCHAR(36) NULL,
    type ENUM('new_booking', 'booking_cancelled', 'booking_rescheduled', 'reminder', 'system') NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    start_at DATETIME NULL,
    end_at DATETIME NULL,
    cancellation_reason TEXT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    metadata JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_notifs_business_unread (business_id, is_read, created_at),
    CONSTRAINT fk_notifs_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_notifs_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_notifs_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. FCM Device Tokens Table
DROP TABLE IF EXISTS fcm_device_tokens;
CREATE TABLE fcm_device_tokens (
    id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NULL,
    business_id VARCHAR(36) NOT NULL,
    token VARCHAR(512) NOT NULL,
    platform ENUM('android', 'ios', 'web', 'macos', 'windows') NOT NULL DEFAULT 'android',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_fcm_token (token),
    INDEX idx_fcm_business (business_id),
    CONSTRAINT fk_fcm_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_fcm_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. Payments Table (Billing & Checkout)
DROP TABLE IF EXISTS payments;
CREATE TABLE payments (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    booking_id VARCHAR(36) NOT NULL,
    customer_id VARCHAR(36) NOT NULL,
    amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    method ENUM('cash', 'upi', 'card', 'online', 'bank_transfer', 'other') NOT NULL DEFAULT 'cash',
    status ENUM('pending', 'completed', 'refunded', 'failed') NOT NULL DEFAULT 'completed',
    transaction_reference VARCHAR(100) NULL,
    paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_payments_booking (booking_id),
    INDEX idx_payments_business_date (business_id, paid_at),
    CONSTRAINT fk_payments_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payments_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payments_customer FOREIGN KEY (customer_id) 
        REFERENCES customers (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. Reviews Table
DROP TABLE IF EXISTS reviews;
CREATE TABLE reviews (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    booking_id VARCHAR(36) NOT NULL,
    customer_id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NULL,
    service_id VARCHAR(36) NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT NULL,
    reply TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_review_booking (booking_id),
    INDEX idx_reviews_business (business_id),
    CONSTRAINT fk_reviews_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_customer FOREIGN KEY (customer_id) 
        REFERENCES customers (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_service FOREIGN KEY (service_id) 
        REFERENCES services (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
```

---

## 7. Sample Initial Seed Data

```sql
-- 1. Insert Demo User
INSERT INTO users (id, full_name, email, phone, password_hash, role)
VALUES (
    'usr-1001-demo',
    'Dr. Prashant Sarvaiya',
    'prashant@appointmentpro.com',
    '9876543210',
    '$2b$10$YourHashedPasswordHereOrBcryptString',
    'owner'
);

-- 2. Insert Demo Business
INSERT INTO businesses (id, owner_id, name, slug, type, country_code, phone, email, currency, timezone, is_active)
VALUES (
    'biz-2001-apex',
    'usr-1001-demo',
    'Apex Wellness Center',
    'apex-wellness-center-1791',
    'Salon / Beauty',
    '+91',
    '9876543210',
    'contact@apexwellness.com',
    'INR',
    'Asia/Kolkata',
    1
);

-- 3. Business Member
INSERT INTO business_members (id, business_id, user_id, role)
VALUES ('bm-3001', 'biz-2001-apex', 'usr-1001-demo', 'owner');

-- 4. Default Operating Hours (Monday to Friday 9am-6pm, Sat 10am-4pm, Sun Closed)
INSERT INTO business_operating_hours (id, business_id, day_of_week, is_open, open_time, close_time) VALUES
('boh-1', 'biz-2001-apex', 1, 1, '09:00:00', '18:00:00'),
('boh-2', 'biz-2001-apex', 2, 1, '09:00:00', '18:00:00'),
('boh-3', 'biz-2001-apex', 3, 1, '09:00:00', '18:00:00'),
('boh-4', 'biz-2001-apex', 4, 1, '09:00:00', '18:00:00'),
('boh-5', 'biz-2001-apex', 5, 1, '09:00:00', '18:00:00'),
('boh-6', 'biz-2001-apex', 6, 1, '10:00:00', '16:00:00'),
('boh-7', 'biz-2001-apex', 7, 0, '09:00:00', '18:00:00');

-- 5. Monday-Friday Lunch Break
INSERT INTO business_schedule_breaks (id, operating_hour_id, break_name, start_time, end_time) VALUES
('bsb-1', 'boh-1', 'Lunch Break', '13:00:00', '14:00:00'),
('bsb-2', 'boh-2', 'Lunch Break', '13:00:00', '14:00:00'),
('bsb-3', 'boh-3', 'Lunch Break', '13:00:00', '14:00:00'),
('bsb-4', 'boh-4', 'Lunch Break', '13:00:00', '14:00:00'),
('bsb-5', 'boh-5', 'Lunch Break', '13:00:00', '14:00:00');

-- 6. Insert Services
INSERT INTO services (id, business_id, name, description, price, duration_minutes, buffer_minutes, is_active) VALUES
('srv-4001', 'biz-2001-apex', 'Haircut & Styling', 'Complete haircut with head massage & blow dry', 499.00, 30, 5, 1),
('srv-4002', 'biz-2001-apex', 'Deep Cleansing Facial', 'Hydrating organic fruit facial with blackhead removal', 999.00, 45, 10, 1),
('srv-4003', 'biz-2001-apex', 'Full Body Swedish Massage', '60 minutes relaxing aromatherapeutic body massage', 1799.00, 60, 15, 1);

-- 7. Insert Staff Members
INSERT INTO staff (id, business_id, user_id, name, email, phone, is_active) VALUES
('stf-5001', 'biz-2001-apex', 'usr-1001-demo', 'Dr. Prashant Sarvaiya', 'prashant@apexwellness.com', '9876543210', 1),
('stf-5002', 'biz-2001-apex', NULL, 'Priya Sharma', 'priya@apexwellness.com', '9876543211', 1),
('stf-5003', 'biz-2001-apex', NULL, 'Rahul Verma', 'rahul@apexwellness.com', '9876543212', 1);

-- 8. Assign Staff to Services
INSERT INTO staff_services (staff_id, service_id) VALUES
('stf-5001', 'srv-4001'),
('stf-5001', 'srv-4002'),
('stf-5002', 'srv-4002'),
('stf-5002', 'srv-4003'),
('stf-5003', 'srv-4001');

-- 9. Insert Sample Customer
INSERT INTO customers (id, business_id, name, country_code, phone, email, notes) VALUES
('cst-6001', 'biz-2001-apex', 'Ananya Gupta', '+91', '9822012345', 'ananya.gupta@gmail.com', 'Prefers herbal hair oil');

-- 10. Insert Sample Booking
INSERT INTO bookings (
    id, booking_reference, business_id, service_id, staff_id, customer_id,
    service_name, staff_name, customer_name, customer_country_code, customer_phone, customer_email,
    start_at, end_at, price, status
) VALUES (
    'bk-7001',
    'BK-10824',
    'biz-2001-apex',
    'srv-4001',
    'stf-5001',
    'cst-6001',
    'Haircut & Styling',
    'Dr. Prashant Sarvaiya',
    'Ananya Gupta',
    '+91',
    '9822012345',
    'ananya.gupta@gmail.com',
    DATE_ADD(CURDATE(), INTERVAL 10 HOUR),
    DATE_ADD(CURDATE(), INTERVAL 10 HOUR + INTERVAL 30 MINUTE),
    499.00,
    'confirmed'
);
```

---

## 8. Backend REST API Endpoint Mapping

The following endpoints directly mirror the Flutter Riverpod repositories:

### Auth Endpoints (`/api/v1/auth`)
- `POST /register`: Registers new owner account (`users` + `user_sessions`)
- `POST /login`: Validates credentials, issues JWT access and refresh token
- `GET /me`: Returns profile of the authenticated user
- `POST /logout`: Invalidate session token

### Business Endpoints (`/api/v1/businesses`)
- `GET /`: List all businesses owned/accessible by authenticated user
- `POST /`: Create a new business profile
- `PUT /:id`: Update business settings, logo, contact
- `PATCH /:id/set-active`: Mark this business as the active context for this user

### Catalog & Staff (`/api/v1/businesses/:businessId/...`)
- `GET/POST /services`: List/create services
- `PUT/DELETE /services/:id`: Update/soft-delete service
- `GET/POST /staff`: List/create staff members
- `PUT/DELETE /staff/:id`: Update staff, toggle active status
- `PUT /staff/:id/services`: Update assigned service IDs (`staff_services`)

### Availability & Scheduling (`/api/v1/businesses/:businessId/...`)
- `GET/PUT /availability`: Get or update 7-day operating hours and break intervals
- `GET/POST /time-off`: List and create holiday/time-off blocks
- `PUT/DELETE /time-off/:id`: Edit or delete holiday records

### Bookings (`/api/v1/businesses/:businessId/bookings`)
- `GET /`: Filter bookings by date range, staff, customer, status
- `POST /`: Create internal booking
- `GET /:id`: Full booking details with reschedule history
- `PATCH /:id/complete`: Transition status to `completed`
- `PATCH /:id/no-show`: Transition status to `noShow`
- `PATCH /:id/cancel`: Transition status to `cancelled` with reason
- `POST /:id/reschedule`: Reschedule to new slot, append to `booking_reschedules`

### Public Client Booking (`/api/v1/public/businesses/:slug/...`)
- `GET /profile`: Public details (business name, logo, type, address, services, staff)
- `GET /slots?serviceId=...&date=YYYY-MM-DD&staffId=...`: Real-time computed booking slots
- `POST /book`: Public appointment creation; creates or matches `customers` record, returns `booking_reference`
- `POST /verify`: Client verification using `booking_reference` + phone number
- `POST /reschedule`: Public client reschedule with conflict re-validation
- `POST /cancel`: Public client cancellation

### Analytics & Reports (`/api/v1/businesses/:businessId/reports/...`)
- `GET /revenue?period=today|week|month|year`: Gross revenue, completed volume, cancellation rate, chart points
- `GET /services?period=...`: Performance breakdown per service
- `GET /staff?period=...`: Staff appointments, completion rate, revenue earned
- `GET /customers`: Customer CRM summary, repeat booking rates, lifetime spend

---

## 9. Migration Guide (LocalStorage to Backend Integration)

To integrate the Flutter client with this backend:
1. **Network Layer:** Add `dio` or `http` to `pubspec.yaml` with an authentication interceptor that attaches the Bearer JWT token.
2. **Replace Local Data Sources:**
   - In `features/bussiness_setup/data/repositories/business_repository.dart`: Replace `_storage.getString(_key)` with `apiClient.get('/businesses')`.
   - In `features/bookings/data/datasources/booking_local_datasource.dart`: Replace `saveBookings` and `getBookings` with corresponding REST calls.
   - In `features/availability/data/repositories/availability_repository.dart`: Fetch operating hours and time-off from the server.
3. **Keep Offline Fallback:** Keep `local_storage_service.dart` as an offline cache layer for fast startup and optimistic UI updates.
