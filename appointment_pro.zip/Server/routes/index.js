const express = require('express');
const router = express.Router();

const authRoutes = require('../modules/auth/auth.routes');
const businessRoutes = require('../modules/businesses/business.routes');
const serviceRoutes = require('../modules/services/service.routes');
const staffRoutes = require('../modules/staff/staff.routes');
const availabilityRoutes = require('../modules/availability/availability.routes');
const customerRoutes = require('../modules/customers/customer.routes');
const bookingRoutes = require('../modules/bookings/booking.routes');
const paymentRoutes = require('../modules/bookings/payment.routes');
const notificationRoutes = require('../modules/notifications/notification.routes');

// Mount routes
router.use('/auth', authRoutes);
router.use('/businesses', businessRoutes);
router.use('/services', serviceRoutes);
router.use('/staff', staffRoutes);
router.use('/availability', availabilityRoutes);
router.use('/operating-hours', availabilityRoutes); // Direct alias
router.use('/customers', customerRoutes);
router.use('/bookings', bookingRoutes);
router.use('/payments', paymentRoutes);
router.use('/notifications', notificationRoutes);

module.exports = router;
