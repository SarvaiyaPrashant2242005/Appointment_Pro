-- ========================================================
-- AppointmentPro: Production MySQL Schema & Seed Script
-- Compatible with: MySQL 8.0+
-- Character set: utf8mb4 | Collation: utf8mb4_unicode_ci
-- ========================================================

CREATE DATABASE IF NOT EXISTS appointment_pro CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE appointment_pro;

SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- 1. Table: users
-- --------------------------------------------------------
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id VARCHAR(36) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(191) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('owner', 'manager', 'staff', 'customer') NOT NULL DEFAULT 'owner',
    avatar_url VARCHAR(500) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    INDEX idx_users_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 2. Table: businesses
-- --------------------------------------------------------
DROP TABLE IF EXISTS businesses;
CREATE TABLE businesses (
    id VARCHAR(36) NOT NULL,
    owner_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) NOT NULL,
    type VARCHAR(100) NOT NULL,
    other_type VARCHAR(100) NULL,
    logo_url VARCHAR(500) NULL,
    email VARCHAR(191) NULL,
    country_code VARCHAR(10) NOT NULL DEFAULT '+91',
    phone VARCHAR(20) NULL,
    currency VARCHAR(10) NOT NULL DEFAULT 'INR',
    timezone VARCHAR(100) NOT NULL DEFAULT 'Asia/Kolkata',
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_businesses_slug (slug),
    INDEX idx_businesses_owner (owner_id),
    CONSTRAINT fk_businesses_owner FOREIGN KEY (owner_id) 
        REFERENCES users (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 3. Table: business_members
-- --------------------------------------------------------
DROP TABLE IF EXISTS business_members;
CREATE TABLE business_members (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NOT NULL,
    role ENUM('owner', 'manager', 'staff') NOT NULL DEFAULT 'staff',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_business_user (business_id, user_id),
    CONSTRAINT fk_bm_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bm_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 4. Table: services
-- --------------------------------------------------------
DROP TABLE IF EXISTS services;
CREATE TABLE services (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    duration_minutes INT NOT NULL DEFAULT 30,
    buffer_minutes INT NOT NULL DEFAULT 0,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_services_business_active (business_id, is_active),
    CONSTRAINT fk_services_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 5. Table: staff
-- --------------------------------------------------------
DROP TABLE IF EXISTS staff;
CREATE TABLE staff (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(191) NULL,
    phone VARCHAR(20) NULL,
    avatar_url VARCHAR(500) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_staff_business_active (business_id, is_active),
    INDEX idx_staff_user (user_id),
    CONSTRAINT fk_staff_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_staff_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 6. Table: staff_services (M:N mapping)
-- --------------------------------------------------------
DROP TABLE IF EXISTS staff_services;
CREATE TABLE staff_services (
    staff_id VARCHAR(36) NOT NULL,
    service_id VARCHAR(36) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (staff_id, service_id),
    INDEX idx_staff_services_service (service_id),
    CONSTRAINT fk_ss_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_ss_service FOREIGN KEY (service_id) 
        REFERENCES services (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 7. Table: business_operating_hours
-- --------------------------------------------------------
DROP TABLE IF EXISTS business_operating_hours;
CREATE TABLE business_operating_hours (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    day_of_week TINYINT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    is_open TINYINT(1) NOT NULL DEFAULT 1,
    open_time TIME NOT NULL DEFAULT '09:00:00',
    close_time TIME NOT NULL DEFAULT '18:00:00',
    PRIMARY KEY (id),
    UNIQUE KEY uq_business_day (business_id, day_of_week),
    CONSTRAINT fk_boh_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 8. Table: business_schedule_breaks
-- --------------------------------------------------------
DROP TABLE IF EXISTS business_schedule_breaks;
CREATE TABLE business_schedule_breaks (
    id VARCHAR(36) NOT NULL,
    operating_hour_id VARCHAR(36) NOT NULL,
    break_name VARCHAR(100) NOT NULL DEFAULT 'Break',
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    PRIMARY KEY (id),
    INDEX idx_breaks_operating_hour (operating_hour_id),
    CONSTRAINT fk_bsb_operating_hour FOREIGN KEY (operating_hour_id) 
        REFERENCES business_operating_hours (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 9. Table: staff_operating_hours
-- --------------------------------------------------------
DROP TABLE IF EXISTS staff_operating_hours;
CREATE TABLE staff_operating_hours (
    id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NOT NULL,
    day_of_week TINYINT NOT NULL CHECK (day_of_week BETWEEN 1 AND 7),
    is_working TINYINT(1) NOT NULL DEFAULT 1,
    start_time TIME NOT NULL DEFAULT '09:00:00',
    close_time TIME NOT NULL DEFAULT '18:00:00',
    PRIMARY KEY (id),
    UNIQUE KEY uq_staff_day (staff_id, day_of_week),
    CONSTRAINT fk_soh_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 10. Table: staff_schedule_breaks
-- --------------------------------------------------------
DROP TABLE IF EXISTS staff_schedule_breaks;
CREATE TABLE staff_schedule_breaks (
    id VARCHAR(36) NOT NULL,
    staff_operating_hour_id VARCHAR(36) NOT NULL,
    break_name VARCHAR(100) NOT NULL DEFAULT 'Break',
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    PRIMARY KEY (id),
    INDEX idx_staff_breaks_hour (staff_operating_hour_id),
    CONSTRAINT fk_ssb_staff_hour FOREIGN KEY (staff_operating_hour_id) 
        REFERENCES staff_operating_hours (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 11. Table: time_off_records (Holidays & Staff Leaves)
-- --------------------------------------------------------
DROP TABLE IF EXISTS time_off_records;
CREATE TABLE time_off_records (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NULL,
    title VARCHAR(255) NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    is_full_day TINYINT(1) NOT NULL DEFAULT 1,
    note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_time_off_query (business_id, staff_id, start_date, end_date),
    CONSTRAINT fk_to_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_to_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 12. Table: customers (CRM Ledger)
-- --------------------------------------------------------
DROP TABLE IF EXISTS customers;
CREATE TABLE customers (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    name VARCHAR(255) NOT NULL,
    country_code VARCHAR(10) NOT NULL DEFAULT '+91',
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(191) NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_customer_business_phone (business_id, phone),
    INDEX idx_customer_business_email (business_id, email),
    CONSTRAINT fk_customers_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 13. Table: bookings
-- --------------------------------------------------------
DROP TABLE IF EXISTS bookings;
CREATE TABLE bookings (
    id VARCHAR(36) NOT NULL,
    booking_reference VARCHAR(20) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    service_id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NULL,
    customer_id VARCHAR(36) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    staff_name VARCHAR(255) NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_country_code VARCHAR(10) NOT NULL DEFAULT '+91',
    customer_phone VARCHAR(20) NOT NULL,
    customer_email VARCHAR(191) NULL,
    customer_notes TEXT NULL,
    start_at DATETIME NOT NULL,
    end_at DATETIME NOT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('confirmed', 'completed', 'cancelled', 'noShow') NOT NULL DEFAULT 'confirmed',
    cancellation_reason TEXT NULL,
    cancelled_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_booking_ref (booking_reference),
    INDEX idx_bookings_availability (business_id, staff_id, status, start_at, end_at),
    INDEX idx_bookings_date_range (business_id, start_at, status),
    INDEX idx_bookings_customer (business_id, customer_id),
    CONSTRAINT fk_bookings_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_bookings_service FOREIGN KEY (service_id) 
        REFERENCES services (id) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_bookings_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_bookings_customer FOREIGN KEY (customer_id) 
        REFERENCES customers (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 14. Table: booking_reschedules (Audit Trail)
-- --------------------------------------------------------
DROP TABLE IF EXISTS booking_reschedules;
CREATE TABLE booking_reschedules (
    id VARCHAR(36) NOT NULL,
    booking_id VARCHAR(36) NOT NULL,
    previous_start_at DATETIME NOT NULL,
    previous_end_at DATETIME NOT NULL,
    new_start_at DATETIME NOT NULL,
    new_end_at DATETIME NOT NULL,
    previous_staff_id VARCHAR(36) NULL,
    new_staff_id VARCHAR(36) NULL,
    reason TEXT NULL,
    rescheduled_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_reschedules_booking (booking_id),
    CONSTRAINT fk_br_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_br_prev_staff FOREIGN KEY (previous_staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_br_new_staff FOREIGN KEY (new_staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 15. Table: notifications
-- --------------------------------------------------------
DROP TABLE IF EXISTS notifications;
CREATE TABLE notifications (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NULL,
    booking_id VARCHAR(36) NULL,
    type ENUM('new_booking', 'booking_cancelled', 'booking_rescheduled', 'reminder', 'system') NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    customer_name VARCHAR(255) NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    start_at DATETIME NULL,
    end_at DATETIME NULL,
    cancellation_reason TEXT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    metadata JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_notifs_business_unread (business_id, is_read, created_at),
    CONSTRAINT fk_notifs_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_notifs_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_notifs_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 16. Table: fcm_device_tokens
-- --------------------------------------------------------
DROP TABLE IF EXISTS fcm_device_tokens;
CREATE TABLE fcm_device_tokens (
    id VARCHAR(36) NOT NULL,
    user_id VARCHAR(36) NULL,
    business_id VARCHAR(36) NOT NULL,
    token VARCHAR(512) NOT NULL,
    platform ENUM('android', 'ios', 'web', 'macos', 'windows') NOT NULL DEFAULT 'android',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_fcm_token (token),
    INDEX idx_fcm_business (business_id),
    CONSTRAINT fk_fcm_user FOREIGN KEY (user_id) 
        REFERENCES users (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_fcm_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 17. Table: payments
-- --------------------------------------------------------
DROP TABLE IF EXISTS payments;
CREATE TABLE payments (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    booking_id VARCHAR(36) NOT NULL,
    customer_id VARCHAR(36) NOT NULL,
    amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    method ENUM('cash', 'upi', 'card', 'online', 'bank_transfer', 'other') NOT NULL DEFAULT 'cash',
    status ENUM('pending', 'completed', 'refunded', 'failed') NOT NULL DEFAULT 'completed',
    transaction_reference VARCHAR(100) NULL,
    paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    INDEX idx_payments_booking (booking_id),
    INDEX idx_payments_business_date (business_id, paid_at),
    CONSTRAINT fk_payments_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payments_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payments_customer FOREIGN KEY (customer_id) 
        REFERENCES customers (id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- 18. Table: reviews
-- --------------------------------------------------------
DROP TABLE IF EXISTS reviews;
CREATE TABLE reviews (
    id VARCHAR(36) NOT NULL,
    business_id VARCHAR(36) NOT NULL,
    booking_id VARCHAR(36) NOT NULL,
    customer_id VARCHAR(36) NOT NULL,
    staff_id VARCHAR(36) NULL,
    service_id VARCHAR(36) NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT NULL,
    reply TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY uq_review_booking (booking_id),
    INDEX idx_reviews_business (business_id),
    CONSTRAINT fk_reviews_business FOREIGN KEY (business_id) 
        REFERENCES businesses (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_booking FOREIGN KEY (booking_id) 
        REFERENCES bookings (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_customer FOREIGN KEY (customer_id) 
        REFERENCES customers (id) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_staff FOREIGN KEY (staff_id) 
        REFERENCES staff (id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_reviews_service FOREIGN KEY (service_id) 
        REFERENCES services (id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
